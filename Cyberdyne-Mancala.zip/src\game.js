/**
 * Mancala Game
 * A 1-player vs CPU implementation of the classic Mancala game
 */

class MancalaGame {
    constructor() {
        // Board setup: 6 pits per player, each with 4 stones
        // Player pits: 0-5, Player store: 6
        // CPU pits: 7-12, CPU store: 13
        this.board = [4, 4, 4, 4, 4, 4, 0, 4, 4, 4, 4, 4, 4, 0];
        this.currentPlayer = 'player'; // 'player' or 'cpu'
        this.gameOver = false;
        this.lastMove = null;
        this.animationInProgress = false;
        
        // Animation settings
        this.animationSpeed = 600; // milliseconds per step (increased from 300)
        this.cpuThinkingTime = 1500; // milliseconds for CPU "thinking"
        
        // DOM elements
        this.statusMessage = document.getElementById('status-message');
        this.resetButton = document.getElementById('reset-button');
        this.rulesButton = document.getElementById('rules-button');
        this.playerStore = document.getElementById('player-store');
        this.cpuStore = document.getElementById('cpu-store');
        this.playerPits = Array.from(document.querySelectorAll('.player-pit'));
        this.cpuPits = Array.from(document.querySelectorAll('.cpu-pit'));
        
        // Modal elements
        this.welcomeModal = document.getElementById('welcome-modal');
        this.rulesModal = document.getElementById('rules-modal');
        this.closeButtons = document.querySelectorAll('.close-button');
        this.startGameButton = document.getElementById('start-game-button');
        this.closeModalButtons = document.querySelectorAll('.close-modal-button');
        
        // Debug elements
        this.debugLog = document.getElementById('debug-log');
        this.toggleDebugButton = document.getElementById('toggle-debug');
        this.debugConsole = document.querySelector('.debug-console');
        this.debugVisible = true;
        
        // Stone colors
        this.stoneColors = [
            '#f5deb3', // wheat
            '#deb887', // burlywood
            '#d2b48c', // tan
            '#bc8f8f', // rosybrown
            '#a9a9a9', // darkgray
            '#808080'  // gray
        ];
        
        // Initialize the game
        this.init();
    }
    
    init() {
        // Add event listeners
        this.resetButton.addEventListener('click', () => this.resetGame());
        this.rulesButton.addEventListener('click', () => this.showRulesModal());
        
        // Add click events to player pits
        this.playerPits.forEach((pit, index) => {
            pit.addEventListener('click', () => this.makeMove(index));
        });
        
        // Modal event listeners
        this.closeButtons.forEach(button => {
            button.addEventListener('click', () => {
                this.welcomeModal.style.display = 'none';
                this.rulesModal.style.display = 'none';
            });
        });
        
        this.closeModalButtons.forEach(button => {
            button.addEventListener('click', () => {
                this.welcomeModal.style.display = 'none';
                this.rulesModal.style.display = 'none';
            });
        });
        
        this.startGameButton.addEventListener('click', () => {
            this.welcomeModal.style.display = 'none';
        });
        
        // Close modal when clicking outside of it
        window.addEventListener('click', (event) => {
            if (event.target === this.welcomeModal) {
                this.welcomeModal.style.display = 'none';
            }
            if (event.target === this.rulesModal) {
                this.rulesModal.style.display = 'none';
            }
        });
        
        // Debug toggle
        this.toggleDebugButton.addEventListener('click', () => {
            if (this.debugVisible) {
                this.debugLog.style.display = 'none';
                this.toggleDebugButton.textContent = 'Show';
                this.debugVisible = false;
            } else {
                this.debugLog.style.display = 'block';
                this.toggleDebugButton.textContent = 'Hide';
                this.debugVisible = true;
            }
        });
        
        // Show welcome modal on first load
        this.showWelcomeModal();
        
        // Initial board state debug
        this.logDebug('Game initialized', this.getBoardStateString());
        
        // Initial render
        this.render();
    }
    
    logDebug(message, data = '') {
        const entry = document.createElement('div');
        entry.className = 'debug-entry';
        
        const timestamp = new Date().toLocaleTimeString();
        entry.innerHTML = `<span>[${timestamp}]</span> ${message}`;
        
        if (data) {
            entry.innerHTML += `<br><span>${data}</span>`;
        }
        
        // Add class for different types of logs
        if (message.includes('Player move')) {
            entry.classList.add('player-move');
        } else if (message.includes('CPU move')) {
            entry.classList.add('cpu-move');
        } else if (message.includes('WARNING') || message.includes('Error')) {
            entry.classList.add('debug-warning');
        }
        
        this.debugLog.appendChild(entry);
        this.debugLog.scrollTop = this.debugLog.scrollHeight;
    }
    
    getBoardStateString() {
        let boardState = 'Board state:\n';
        boardState += `CPU Store (13): ${this.board[13]}\n`;
        boardState += 'CPU Pits:    ';
        for (let i = 12; i >= 7; i--) {
            boardState += `${this.board[i]} `;
        }
        boardState += '\nPlayer Pits: ';
        for (let i = 0; i < 6; i++) {
            boardState += `${this.board[i]} `;
        }
        boardState += `\nPlayer Store (6): ${this.board[6]}`;
        return boardState;
    }
    
    showWelcomeModal() {
        this.welcomeModal.style.display = 'block';
    }
    
    showRulesModal() {
        this.rulesModal.style.display = 'block';
    }
    
    resetGame() {
        // Stop any animations in progress
        this.animationInProgress = false;
        
        // Reset board state
        this.board = [4, 4, 4, 4, 4, 4, 0, 4, 4, 4, 4, 4, 4, 0];
        this.currentPlayer = 'player';
        this.gameOver = false;
        this.lastMove = null;
        
        // Update UI
        this.render();
        this.setStatusMessage('Your turn');
        
        // Log reset
        this.logDebug('Game reset', this.getBoardStateString());
    }
    
    makeMove(pitIndex) {
        // Check if game is over, animation in progress, or if it's not player's turn
        if (this.gameOver || this.currentPlayer !== 'player' || this.animationInProgress) {
            return;
        }
        
        // Check if the selected pit is valid (belongs to player and has stones)
        if (pitIndex < 0 || pitIndex > 5 || this.board[pitIndex] === 0) {
            return;
        }
        
        // Log the move
        this.logDebug(`Player move: Pit ${pitIndex} (${this.board[pitIndex]} stones)`);
        
        // Animate the move
        this.animateMove(pitIndex, 'player');
    }
    
    // Process the player's move after animation
    processMoveAfterAnimation(pitIndex, player) {
        // Execute the move on the actual board state
        const extraTurn = this.sowStones(pitIndex, player);
        this.lastMove = pitIndex;
        
        // Log board state after move
        this.logDebug(`After ${player} move:`, this.getBoardStateString());
        
        // Check if the game is over
        if (this.checkGameOver()) {
            this.endGame();
            return;
        }
        
        // Render the updated board to show actual state
        this.render();
        
        // Check if player gets an extra turn
        if (extraTurn) {
            if (player === 'player') {
                this.setStatusMessage('You get another turn!');
                this.logDebug('Player gets another turn');
            } else {
                this.setStatusMessage('CPU gets another turn');
                this.logDebug('CPU gets another turn');
                setTimeout(() => this.cpuTurn(), this.cpuThinkingTime);
            }
        } else {
            // Switch turns
            if (player === 'player') {
                this.currentPlayer = 'cpu';
                this.setStatusMessage('CPU is thinking...');
                setTimeout(() => this.cpuTurn(), this.cpuThinkingTime);
            } else {
                this.currentPlayer = 'player';
                this.setStatusMessage('Your turn');
            }
        }
    }
    
    animateMove(pitIndex, player) {
        // Mark animation as in progress
        this.animationInProgress = true;
        
        // Get the stones to distribute
        const stones = this.board[pitIndex];
        if (stones === 0) {
            this.animationInProgress = false;
            return;
        }
        
        // Create a copy of the board state before making changes
        const originalBoard = [...this.board];
        
        // Remove stones from the starting pit in UI only (actual board state is changed in sowStones)
        this.board[pitIndex] = 0;
        
        // Get the container element
        let sourceContainer;
        if (player === 'player') {
            sourceContainer = this.playerPits[pitIndex];
        } else {
            sourceContainer = this.cpuPits[12 - pitIndex];
        }
        
        // Render to show empty pit
        this.render();
        
        // Create visual stones for animation
        const animatedStones = [];
        for (let i = 0; i < stones; i++) {
            const stone = document.createElement('div');
            stone.className = 'stone animated-stone';
            
            // Random color
            const colorIndex = Math.floor(Math.random() * this.stoneColors.length);
            stone.style.backgroundColor = this.stoneColors[colorIndex];
            
            // Initial position in source pit
            const containerRect = sourceContainer.getBoundingClientRect();
            const left = Math.random() * (containerRect.width - 15);
            const top = Math.random() * (containerRect.height - 15);
            
            stone.style.left = `${left}px`;
            stone.style.top = `${top}px`;
            
            sourceContainer.appendChild(stone);
            animatedStones.push(stone);
        }
        
        // Restore the board state for simulation
        this.board = [...originalBoard];
        
        // Simulate the move to determine the path without changing the actual board
        const movePath = this.simulateMovePath(pitIndex, player);
        
        // Animate the distribution of stones
        this.animateDistribution(pitIndex, player, animatedStones, 0, movePath);
    }
    
    simulateMovePath(pitIndex, player) {
        // Create a path of pits that stones will move through
        const stones = this.board[pitIndex];
        const path = [];
        let currentPit = pitIndex;
        
        // Properly handle counter-clockwise movement based on the visual board layout
        // Player pits: 0,1,2,3,4,5 (bottom row, left to right)
        // Player store: 6 (rightmost)
        // CPU pits: 7,8,9,10,11,12 (top row, right to left)
        // CPU store: 13 (leftmost)
        
        for (let i = 0; i < stones; i++) {
            // Determine next pit in counter-clockwise order
            if (currentPit === 5) {
                // From rightmost player pit to player store
                currentPit = 6;
            } else if (currentPit === 6) {
                // From player store to rightmost CPU pit
                currentPit = 12;
            } else if (currentPit === 7) {
                // From leftmost CPU pit to CPU store
                currentPit = 13;
            } else if (currentPit === 13) {
                // From CPU store to leftmost player pit
                currentPit = 0;
            } else if (currentPit >= 0 && currentPit < 5) {
                // Moving right along player's row
                currentPit++;
            } else if (currentPit > 7 && currentPit <= 12) {
                // Moving left along CPU's row
                currentPit--;
            }
            
            // Skip opponent's store
            if (player === 'player' && currentPit === 13) {
                // Player skips CPU's store
                currentPit = 0;
            } else if (player === 'cpu' && currentPit === 6) {
                // CPU skips player's store
                currentPit = 12;
            }
            
            path.push(currentPit);
        }
        
        return path;
    }
    
    animateDistribution(pitIndex, player, stones, currentStone, movePath) {
        if (currentStone >= stones.length || !this.animationInProgress) {
            // Animation completed or cancelled
            this.removeAnimatedStones();
            // Now we actually make the move after the animation
            this.processMoveAfterAnimation(pitIndex, player);
            return;
        }
        
        // Get the target pit from the pre-calculated path
        const targetPit = movePath[currentStone];
        
        // Get the stone to animate
        const stone = stones[currentStone];
        
        // Get target container
        let targetContainer;
        if (targetPit === 6) {
            targetContainer = this.playerStore;
        } else if (targetPit === 13) {
            targetContainer = this.cpuStore;
        } else if (targetPit >= 0 && targetPit <= 5) {
            targetContainer = this.playerPits[targetPit];
        } else {
            targetContainer = this.cpuPits[12 - targetPit];
        }
        
        // Get the position and dimensions
        const targetRect = targetContainer.getBoundingClientRect();
        const sourceRect = stone.parentElement.getBoundingClientRect();
        
        // Calculate new position
        const centerX = targetRect.left + targetRect.width / 2 - sourceRect.left;
        const centerY = targetRect.top + targetRect.height / 2 - sourceRect.top;
        
        // Add randomness to final position
        const finalX = centerX + (Math.random() * 30 - 15);
        const finalY = centerY + (Math.random() * 30 - 15);
        
        // Animate the stone
        stone.style.transition = `transform ${this.animationSpeed}ms ease-in-out`;
        stone.style.transform = `translate(${finalX}px, ${finalY}px)`;
        
        // Visual feedback - DO NOT update the actual stone count
        // This will just show movement in the UI
        targetContainer.classList.add('active');
        setTimeout(() => {
            targetContainer.classList.remove('active');
        }, this.animationSpeed);
        
        // Move the stone to the target container after animation
        setTimeout(() => {
            if (!this.animationInProgress) return;
            
            try {
                targetContainer.appendChild(stone);
                stone.style.transform = 'none';
                stone.style.transition = 'none';
                
                // Position the stone randomly in the new container
                const containerWidth = targetContainer.clientWidth - 15;
                const containerHeight = targetContainer.clientHeight - 15;
                const left = Math.random() * containerWidth;
                const top = Math.random() * containerHeight;
                
                stone.style.left = `${left}px`;
                stone.style.top = `${top}px`;
                
                // Continue to next stone
                setTimeout(() => {
                    this.animateDistribution(pitIndex, player, stones, currentStone + 1, movePath);
                }, 50);
            } catch (e) {
                console.error("Animation error:", e);
                // Gracefully handle error by stopping animation
                this.removeAnimatedStones();
                this.processMoveAfterAnimation(pitIndex, player);
            }
        }, this.animationSpeed);
    }
    
    removeAnimatedStones() {
        document.querySelectorAll('.animated-stone').forEach(stone => {
            stone.remove();
        });
        this.animationInProgress = false;
    }
    
    sowStones(pitIndex, player) {
        const stones = this.board[pitIndex];
        this.board[pitIndex] = 0;
        
        let currentPit = pitIndex;
        let lastPit = null;
        let extraTurn = false;
        
        // Properly handle counter-clockwise movement based on the visual board layout
        // Player pits: 0,1,2,3,4,5 (bottom row, left to right)
        // Player store: 6 (rightmost)
        // CPU pits: 7,8,9,10,11,12 (top row, right to left)
        // CPU store: 13 (leftmost)
        
        for (let i = 0; i < stones; i++) {
            // Determine next pit in counter-clockwise order
            if (currentPit === 5) {
                // From rightmost player pit to player store
                currentPit = 6;
            } else if (currentPit === 6) {
                // From player store to rightmost CPU pit
                currentPit = 12;
            } else if (currentPit === 7) {
                // From leftmost CPU pit to CPU store
                currentPit = 13;
            } else if (currentPit === 13) {
                // From CPU store to leftmost player pit
                currentPit = 0;
            } else if (currentPit >= 0 && currentPit < 5) {
                // Moving right along player's row
                currentPit++;
            } else if (currentPit > 7 && currentPit <= 12) {
                // Moving left along CPU's row
                currentPit--;
            }
            
            // Skip opponent's store
            if (player === 'player' && currentPit === 13) {
                // Player skips CPU's store
                currentPit = 0;
            } else if (player === 'cpu' && currentPit === 6) {
                // CPU skips player's store
                currentPit = 12;
            }
            
            // Add stone to the current pit
            this.board[currentPit]++;
            lastPit = currentPit;
        }
        
        // Check if last stone landed in player's own store
        if ((player === 'player' && lastPit === 6) || (player === 'cpu' && lastPit === 13)) {
            extraTurn = true;
        }
        
        // Check for capture
        if (!extraTurn) {
            // Player capture condition: last stone lands in an empty pit on player's side
            if (player === 'player' && lastPit >= 0 && lastPit <= 5 && this.board[lastPit] === 1) {
                const oppositePit = 12 - lastPit;
                if (this.board[oppositePit] > 0) {
                    // Capture opposite stones and the capturing stone
                    this.board[6] += this.board[oppositePit] + 1;
                    this.board[oppositePit] = 0;
                    this.board[lastPit] = 0;
                }
            }
            // CPU capture condition: last stone lands in an empty pit on CPU's side
            else if (player === 'cpu' && lastPit >= 7 && lastPit <= 12 && this.board[lastPit] === 1) {
                const oppositePit = 12 - lastPit;
                if (this.board[oppositePit] > 0) {
                    // Capture opposite stones and the capturing stone
                    this.board[13] += this.board[oppositePit] + 1;
                    this.board[oppositePit] = 0;
                    this.board[lastPit] = 0;
                }
            }
        }
        
        return extraTurn;
    }
    
    simulateMove(pitIndex) {
        // Create a copy of the board for simulation
        this.simulateBoardState = [...this.board];
        
        const stones = this.simulateBoardState[pitIndex];
        this.simulateBoardState[pitIndex] = 0;
        
        let currentPit = pitIndex;
        let lastPit = null;
        
        // Properly handle counter-clockwise movement based on the visual board layout
        // Player pits: 0,1,2,3,4,5 (bottom row, left to right)
        // Player store: 6 (rightmost)
        // CPU pits: 7,8,9,10,11,12 (top row, right to left)
        // CPU store: 13 (leftmost)
        
        for (let i = 0; i < stones; i++) {
            // Determine next pit in counter-clockwise order
            if (currentPit === 5) {
                // From rightmost player pit to player store
                currentPit = 6;
            } else if (currentPit === 6) {
                // From player store to rightmost CPU pit
                currentPit = 12;
            } else if (currentPit === 7) {
                // From leftmost CPU pit to CPU store
                currentPit = 13;
            } else if (currentPit === 13) {
                // From CPU store to leftmost player pit
                currentPit = 0;
            } else if (currentPit >= 0 && currentPit < 5) {
                // Moving right along player's row
                currentPit++;
            } else if (currentPit > 7 && currentPit <= 12) {
                // Moving left along CPU's row
                currentPit--;
            }
            
            // Skip player's store (CPU is moving)
            if (currentPit === 6) {
                currentPit = 12;
            }
            
            // Add stone to the current pit
            this.simulateBoardState[currentPit]++;
            lastPit = currentPit;
        }
        
        return lastPit;
    }
    
    cpuTurn() {
        if (this.gameOver || this.animationInProgress) return;
        
        // Choose a move based on simple heuristic
        const pitIndex = this.chooseCpuMove();
        
        if (pitIndex !== null) {
            // Log the CPU move
            this.logDebug(`CPU move: Pit ${pitIndex} (${this.board[pitIndex]} stones)`);
            
            // Animate the CPU move
            this.animateMove(pitIndex, 'cpu');
        } else {
            // No valid move for CPU
            this.logDebug('WARNING: No valid move for CPU');
            this.endGame();
        }
    }
    
    chooseCpuMove() {
        // Strategy priority:
        // 1. If can land in own store (extra turn), choose that move
        // 2. If can capture opponent's stones, choose that move
        // 3. Otherwise, choose pit with most stones
        
        let bestPit = null;
        let bestValue = -1;
        let reason = "";
        
        // Debug log all possible CPU moves
        this.logDebug('CPU analyzing moves:');
        
        // Check all CPU pits (7-12)
        for (let i = 7; i <= 12; i++) {
            // Skip empty pits
            if (this.board[i] === 0) {
                this.logDebug(`- Pit ${i}: EMPTY`);
                continue;
            }
            
            // Calculate where the last stone will land
            const stones = this.board[i];
            
            // Simulate the distribution
            let lastPit = this.simulateMove(i);
            
            // Check if this move leads to an extra turn
            if (lastPit === 13) {
                this.logDebug(`- Pit ${i}: CHOSEN - Will land in store (extra turn)`);
                return i; // Found a move that gives extra turn
            }
            
            // Check if this move leads to a capture
            if (lastPit >= 7 && lastPit <= 12 && 
                this.simulateBoardState[lastPit] === 1 && // last stone made it exactly 1
                this.board[12 - lastPit] > 0) { // there are stones to capture
                this.logDebug(`- Pit ${i}: CHOSEN - Will capture ${this.board[12 - lastPit]} stones from pit ${12 - lastPit}`);
                return i; // Found a move that gives capture
            }
            
            // Otherwise, consider this pit based on number of stones
            this.logDebug(`- Pit ${i}: ${stones} stones, last stone lands in pit ${lastPit}`);
            if (this.board[i] > bestValue) {
                bestValue = this.board[i];
                bestPit = i;
                reason = "most stones";
            }
        }
        
        if (bestPit !== null) {
            this.logDebug(`- Pit ${bestPit} chosen (${reason})`);
        }
        
        return bestPit;
    }
    
    checkGameOver() {
        // Check if all pits on either side are empty
        const playerSideEmpty = this.board.slice(0, 6).every(stones => stones === 0);
        const cpuSideEmpty = this.board.slice(7, 13).every(stones => stones === 0);
        
        if (playerSideEmpty || cpuSideEmpty) {
            this.logDebug(`Game over detected: ${playerSideEmpty ? 'Player' : 'CPU'} side is empty`);
            return true;
        }
        
        return false;
    }
    
    endGame() {
        // Log the end game state before moving stones
        this.logDebug('End game state before final collection:', this.getBoardStateString());
        
        // Move all remaining stones to the respective stores
        let playerRemaining = 0;
        for (let i = 0; i < 6; i++) {
            playerRemaining += this.board[i];
            this.board[6] += this.board[i];
            this.board[i] = 0;
        }
        
        let cpuRemaining = 0;
        for (let i = 7; i < 13; i++) {
            cpuRemaining += this.board[i];
            this.board[13] += this.board[i];
            this.board[i] = 0;
        }
        
        this.logDebug(`Final collection: Player +${playerRemaining}, CPU +${cpuRemaining}`);
        
        this.gameOver = true;
        this.render();
        
        // Determine winner
        const playerScore = this.board[6];
        const cpuScore = this.board[13];
        
        if (playerScore > cpuScore) {
            this.setStatusMessage(`Game over! You win! 🎉 (${playerScore}-${cpuScore})`);
            this.logDebug(`Player wins ${playerScore}-${cpuScore}`);
        } else if (playerScore < cpuScore) {
            this.setStatusMessage(`Game over! CPU wins! 😔 (${cpuScore}-${playerScore})`);
            this.logDebug(`CPU wins ${cpuScore}-${playerScore}`);
        } else {
            this.setStatusMessage(`Game over! It's a tie! 🤝 (${playerScore}-${cpuScore})`);
            this.logDebug(`Tie game ${playerScore}-${cpuScore}`);
        }
    }
    
    render() {
        // Clear all stones first (except animated ones)
        document.querySelectorAll('.stone:not(.animated-stone)').forEach(stone => stone.remove());
        
        // Update player pits
        for (let i = 0; i < 6; i++) {
            const pit = this.playerPits[i];
            const count = this.board[i];
            pit.querySelector('.stones-count').textContent = count;
            
            // Add visual stones
            this.renderStones(pit, count);
            
            // Enable/disable pits based on game state
            if (this.currentPlayer === 'player' && count > 0 && !this.gameOver && !this.animationInProgress) {
                pit.classList.remove('disabled');
            } else {
                pit.classList.add('disabled');
            }
        }
        
        // Update CPU pits
        for (let i = 0; i < 6; i++) {
            const pit = this.cpuPits[i];
            const count = this.board[12 - i];
            pit.querySelector('.stones-count').textContent = count;
            pit.classList.add('disabled'); // CPU pits are always disabled for player
            
            // Add visual stones
            this.renderStones(pit, count);
        }
        
        // Update stores
        this.playerStore.querySelector('.store-count').textContent = this.board[6];
        this.cpuStore.querySelector('.store-count').textContent = this.board[13];
        
        // Add visual stones to stores
        this.renderStones(this.playerStore, this.board[6], true);
        this.renderStones(this.cpuStore, this.board[13], true);
    }
    
    renderStones(container, count, isStore = false) {
        // Skip rendering if there are animated stones in progress
        if (container.querySelector('.animated-stone')) {
            return;
        }
        
        // Don't render too many stones visually
        const maxVisualStones = isStore ? 30 : 15;
        const visibleCount = Math.min(count, maxVisualStones);
        
        for (let i = 0; i < visibleCount; i++) {
            const stone = document.createElement('div');
            stone.className = 'stone';
            
            // Random position within the container
            const containerWidth = container.clientWidth - 15;
            const containerHeight = container.clientHeight - 15;
            
            let left, top;
            
            if (isStore) {
                // For stores, distribute more evenly
                const rows = Math.ceil(Math.sqrt(visibleCount));
                const cols = Math.ceil(visibleCount / rows);
                const row = Math.floor(i / cols);
                const col = i % cols;
                
                const cellWidth = containerWidth / cols;
                const cellHeight = containerHeight / rows;
                
                left = col * cellWidth + Math.random() * 10 - 5;
                top = row * cellHeight + Math.random() * 10 - 5;
            } else {
                // For pits, more random distribution
                left = Math.random() * containerWidth;
                top = Math.random() * containerHeight;
            }
            
            // Ensure stones stay within bounds
            left = Math.max(5, Math.min(containerWidth - 5, left));
            top = Math.max(5, Math.min(containerHeight - 5, top));
            
            stone.style.left = left + 'px';
            stone.style.top = top + 'px';
            
            // Random color from our palette
            const colorIndex = Math.floor(Math.random() * this.stoneColors.length);
            stone.style.backgroundColor = this.stoneColors[colorIndex];
            
            // Random rotation for natural look
            const rotation = Math.random() * 360;
            stone.style.transform = `rotate(${rotation}deg)`;
            
            container.appendChild(stone);
        }
    }
    
    setStatusMessage(message) {
        this.statusMessage.textContent = message;
    }
}

// Start the game when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new MancalaGame();
}); 